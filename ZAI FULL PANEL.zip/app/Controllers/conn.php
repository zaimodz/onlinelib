<?php

$servername = "localhost";
$dbname = "bifytptm_name";
$username = "bifytptm_name";
$password = "2cXMx5L7jXB7gS6Cdd7s";

$conn = mysqli_connect($servername,$username,$password,$dbname);

if(!$conn) {

die(" PROBLEM WITH CONNECTION : " . mysqli_connect_error());

}
  
?>